-- ============================================================================
-- MASTER_BOY Database Migration 002: Seed Data
-- Populates 8 Georgian cities, 8 professions, bootstrap admin & super admin,
-- initial Top 15 pricing (50.00 GEL), and verified craftsmen.
-- ============================================================================

-- 1. Cities in Georgia
INSERT INTO cities (id, name_ka, name_ru, name_en, lat, lng, is_active, display_order)
VALUES
    ('city-tbilisi', 'თბილისი', 'Тбилиси', 'Tbilisi', 41.7151, 44.8271, true, 1),
    ('city-batumi', 'ბათუმი', 'Батуми', 'Batumi', 41.6168, 41.6367, true, 2),
    ('city-kutaisi', 'ქუთაისი', 'Кутаиси', 'Kutaisi', 42.2662, 42.7180, true, 3),
    ('city-rustavi', 'რუსთავი', 'Рустави', 'Rustavi', 41.5495, 44.9932, true, 4),
    ('city-gori', 'გორი', 'Гори', 'Gori', 41.9842, 44.1158, true, 5),
    ('city-zugdidi', 'ზუგდიდი', 'Зугдиди', 'Zugdidi', 42.5088, 41.8709, true, 6),
    ('city-poti', 'ფოთი', 'Поти', 'Poti', 42.1462, 41.6720, true, 7),
    ('city-telavi', 'თელავი', 'Телави', 'Telavi', 41.9198, 45.4731, true, 8)
ON CONFLICT (id) DO NOTHING;

-- 2. Professional Categories
INSERT INTO professions (id, name_ka, name_ru, name_en, icon, display_order, is_active)
VALUES
    ('prof-plumber', 'სანტექნიკოსი', 'Сантехник', 'Plumber', 'Wrench', 1, true),
    ('prof-electrician', 'ელექტრიკოსი', 'Электрик', 'Electrician', 'Zap', 2, true),
    ('prof-ac', 'კონდიციონერის ხელოსანი', 'Мастер кондиционеров', 'HVAC / AC Master', 'Wind', 3, true),
    ('prof-carpenter', 'ავეჯის ხელოსანი / დურგალი', 'Мебельщик / Плотник', 'Furniture / Carpenter', 'Hammer', 4, true),
    ('prof-painter', 'მღებავი / სამღებრო', 'Маляр', 'Painter', 'Paintbrush', 5, true),
    ('prof-tiler', 'მეკაფელე', 'Плиточник', 'Tiler', 'Layers', 6, true),
    ('prof-locksmith', 'საკეტების ხელოსანი', 'Замочный мастер', 'Locksmith', 'Key', 7, true),
    ('prof-heating', 'გათბობის ხელოსანი', 'Мастер по отоплению', 'Heating Specialist', 'Flame', 8, true)
ON CONFLICT (id) DO NOTHING;

-- 3. Super Administrator & Staff Administrator
INSERT INTO users (id, phone, password_hash, roles, status)
VALUES
    ('usr-superadmin', '+995000000000', 'UNUSABLE_SEED_PASSWORD', ARRAY['SUPER_ADMIN']::user_role[], 'ACTIVE'),
    ('usr-admin', '+995999000000', 'UNUSABLE_SEED_PASSWORD', ARRAY['ADMIN']::user_role[], 'ACTIVE')
ON CONFLICT (phone) DO NOTHING;

-- 4. Initial Top 15 Prices (50.00 GEL for all categories)
INSERT INTO top15_prices (id, city_id, profession_id, amount_minor, currency, updated_at)
SELECT
    c.id || ':' || p.id AS id,
    c.id AS city_id,
    p.id AS profession_id,
    5000 AS amount_minor,
    'GEL' AS currency,
    NOW() AS updated_at
FROM cities c
CROSS JOIN professions p
ON CONFLICT (id) DO NOTHING;

-- 5. Seed System Config
INSERT INTO system_config (
    id,
    config_locked,
    recipient_bank_name,
    recipient_iban,
    recipient_tax_id,
    recipient_company_name,
    standard_listing_price_minor
) VALUES (
    'global_config',
    false,
    'TBC Bank JSC',
    '',
    '',
    'MASTER_BOY LLC',
    5000
) ON CONFLICT (id) DO NOTHING;

-- 6. Demo Craftsman Accounts & Listings
INSERT INTO users (id, phone, password_hash, roles, status)
VALUES
    ('usr-cm-1', '+995599112233', 'UNUSABLE_SEED_PASSWORD', ARRAY['CRAFTSMAN']::user_role[], 'ACTIVE'),
    ('usr-cm-2', '+995577445566', 'UNUSABLE_SEED_PASSWORD', ARRAY['CRAFTSMAN']::user_role[], 'ACTIVE'),
    ('usr-cm-3', '+995555889900', 'UNUSABLE_SEED_PASSWORD', ARRAY['CRAFTSMAN']::user_role[], 'ACTIVE'),
    ('usr-cm-4', '+995593123456', 'UNUSABLE_SEED_PASSWORD', ARRAY['CRAFTSMAN']::user_role[], 'ACTIVE'),
    ('usr-cm-5', '+995577112244', 'UNUSABLE_SEED_PASSWORD', ARRAY['CRAFTSMAN']::user_role[], 'ACTIVE')
ON CONFLICT (phone) DO NOTHING;

INSERT INTO craftsmen (id, user_id, name, description, phone, phone_visible, city_id, profession_id, latitude, longitude, status)
VALUES
    ('cm-1', 'usr-cm-1', 'გიორგი ბერიძე', 'პროფესიონალი სანტექნიკოსი 12 წლიანი გამოცდილებით. ნებისმიერი სირთულის მილების მონტაჟი.', '+995599112233', true, 'city-tbilisi', 'prof-plumber', 41.7151, 44.8271, 'ACTIVE'),
    ('cm-2', 'usr-cm-2', 'დავით მამულაშვილი', 'სერთიფიცირებული ელექტრიკოსი. ბინების და ოფისების სრული ელექტროგაყვანილობა.', '+995577445566', true, 'city-tbilisi', 'prof-electrician', 41.7250, 44.7500, 'ACTIVE'),
    ('cm-3', 'usr-cm-3', 'ლევან ყიფიანი', 'კონდიციონერების მონტაჟი, წმენდა და ფრეონით დატუმბვა გარანტიით.', '+995555889900', true, 'city-tbilisi', 'prof-ac', 41.7300, 44.8000, 'ACTIVE'),
    ('cm-4', 'usr-cm-4', 'ირაკლი გელოვანი', 'ავეჯის დამზადება, აწყობა, რესტავრაცია. ინდივიდუალური პროექტები.', '+995593123456', false, 'city-tbilisi', 'prof-carpenter', 41.7100, 44.7800, 'ACTIVE'),
    ('cm-5', 'usr-cm-5', 'ვახტანგ ჯაფარიძე', 'მაღალი ხარისხის სამღებრო და სამალიარო სამუშაოები. შპალერი, ლამინატი.', '+995577112244', true, 'city-batumi', 'prof-painter', 41.6168, 41.6367, 'ACTIVE')
ON CONFLICT (id) DO NOTHING;

-- Initial Photos for Craftsmen
INSERT INTO craftsman_photos (id, craftsman_id, url, is_primary, display_order)
VALUES
    ('ph-1', 'cm-1', 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=600&q=80', true, 0),
    ('ph-2', 'cm-2', 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=600&q=80', true, 0),
    ('ph-3', 'cm-3', 'https://images.unsplash.com/photo-1581092921461-eab62e97a780?auto=format&fit=crop&w=600&q=80', true, 0),
    ('ph-4', 'cm-4', 'https://images.unsplash.com/photo-1541888946425-d0fbb186156f?auto=format&fit=crop&w=600&q=80', true, 0),
    ('ph-5', 'cm-5', 'https://images.unsplash.com/photo-1562259949-e8e7689d7828?auto=format&fit=crop&w=600&q=80', true, 0)
ON CONFLICT (id) DO NOTHING;

-- Listings (180 days validity)
INSERT INTO craftsman_listings (id, craftsman_id, city_id, profession_id, status, starts_at, expires_at, grace_ends_at)
VALUES
    ('list-cm-1', 'cm-1', 'city-tbilisi', 'prof-plumber', 'ACTIVE', NOW(), NOW() + INTERVAL '180 days', NOW() + INTERVAL '210 days'),
    ('list-cm-2', 'cm-2', 'city-tbilisi', 'prof-electrician', 'ACTIVE', NOW(), NOW() + INTERVAL '180 days', NOW() + INTERVAL '210 days'),
    ('list-cm-3', 'cm-3', 'city-tbilisi', 'prof-ac', 'ACTIVE', NOW(), NOW() + INTERVAL '180 days', NOW() + INTERVAL '210 days'),
    ('list-cm-4', 'cm-4', 'city-tbilisi', 'prof-carpenter', 'ACTIVE', NOW(), NOW() + INTERVAL '180 days', NOW() + INTERVAL '210 days'),
    ('list-cm-5', 'cm-5', 'city-batumi', 'prof-painter', 'ACTIVE', NOW(), NOW() + INTERVAL '180 days', NOW() + INTERVAL '210 days')
ON CONFLICT (id) DO NOTHING;

-- Sample Top 15 memberships
INSERT INTO top15_memberships (id, city_id, profession_id, craftsman_id, status, starts_at, expires_at)
VALUES
    ('top-1', 'city-tbilisi', 'prof-plumber', 'cm-1', 'ACTIVE', NOW(), NOW() + INTERVAL '30 days'),
    ('top-2', 'city-tbilisi', 'prof-electrician', 'cm-2', 'ACTIVE', NOW(), NOW() + INTERVAL '30 days')
ON CONFLICT (id) DO NOTHING;
