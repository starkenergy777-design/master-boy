import React from 'react';
import { Globe, Shield, LogOut, Check } from 'lucide-react';
import { translations } from '../i18n.js';
import { Language, User } from '../types.js';

interface SettingsScreenProps {
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  currentUser: User | null;
  onLogout: () => void;
  onBack?: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  lang,
  onLanguageChange,
  currentUser,
  onLogout,
  onBack,
}) => {
  const t = translations[lang] || translations.ka;

  const languages: { code: Language; label: string; flag: string }[] = [
    { code: 'ka', label: 'ქართული', flag: '🇬🇪' },
    { code: 'ru', label: 'Русский', flag: '🇷🇺' },
    { code: 'en', label: 'English', flag: '🇬🇧' },
  ];

  return (
    <div className="flex-1 flex flex-col p-4 pb-20 space-y-4 animate-fade-in text-slate-100">
      <div className="flex items-center gap-2">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Globe className="w-5 h-5 text-amber-400" />
          <span>{t.settings}</span>
        </h2>
      </div>

      {/* Language Selector (§8: 3 languages only: ka, ru, en) */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 space-y-3">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
          {t.language}
        </h3>

        <div className="grid grid-cols-1 gap-2">
          {languages.map((l) => (
            <button
              key={l.code}
              onClick={() => onLanguageChange(l.code)}
              className={`flex items-center justify-between p-3 rounded-2xl border text-xs font-semibold transition-all ${
                lang === l.code
                  ? 'bg-amber-500/10 border-amber-500 text-white'
                  : 'bg-slate-950/60 border-slate-800/80 text-slate-400 hover:border-slate-700'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <span className="text-base">{l.flag}</span>
                <span>{l.label}</span>
              </span>
              {lang === l.code && <Check className="w-4 h-4 text-amber-400" />}
            </button>
          ))}
        </div>
      </div>

      {/* Platform Info */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 space-y-2.5 text-xs">
        <h3 className="font-bold text-amber-400 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
          <Shield className="w-3.5 h-3.5 text-amber-400" />
          <span>{lang === 'ka' ? 'პლატფორმის შესახებ' : 'About Platform'}</span>
        </h3>
        <ul className="space-y-1.5 text-slate-300 text-xs">
          <li className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
            <span>{lang === 'ka' ? 'საქართველოს მასშტაბით ხელოსნებთან პირდაპირი დაკავშირება' : 'Direct contact with craftsmen across Georgia'}</span>
          </li>
          <li className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
            <span>{lang === 'ka' ? 'Top 15 პრიორიტეტული და შემოწმებული პროფესიონალები' : 'Top 15 premier verified professionals'}</span>
          </li>
          <li className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
            <span>{lang === 'ka' ? 'მომხმარებელთა კონფიდენციალურობა და უსაფრთხოება' : 'User privacy and data security'}</span>
          </li>
        </ul>
      </div>



      {currentUser && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 space-y-3 text-xs">
          <h3 className="font-bold text-slate-300 uppercase tracking-wider text-[11px]">
            Active Session
          </h3>
          <div className="space-y-1 text-slate-400 text-[11px]">
            <p>Phone: <strong className="text-white font-mono">{currentUser.phone}</strong></p>
            <p>Roles: <strong className="text-amber-400">{currentUser.roles.join(', ')}</strong></p>
          </div>

          <button
            onClick={onLogout}
            className="w-full mt-2 bg-rose-950/60 hover:bg-rose-900 text-rose-300 font-bold py-2.5 px-3 rounded-xl border border-rose-800/80 flex items-center justify-center gap-2 text-xs transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>{t.logout}</span>
          </button>
        </div>
      )}

      <div className="text-center pt-4 text-[11px] text-slate-500">
        MASTER_BOY • {new Date().getFullYear()}
      </div>
    </div>
  );
};
