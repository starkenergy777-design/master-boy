import React, { useState, useEffect } from 'react';
import { MapPin, Navigation, Phone, Sliders, EyeOff, Star } from 'lucide-react';
import { translations } from '../i18n.js';
import { Language, CraftsmanPublic } from '../types.js';
import { api } from '../api.js';

interface MapSearchScreenProps {
  lang: Language;
  onSelectCraftsman: (craftsman: CraftsmanPublic) => void;
  onCall: (craftsman: CraftsmanPublic) => void;
  onBack?: () => void;
  presetLat?: number | null;
  presetLng?: number | null;
}

export const MapSearchScreen: React.FC<MapSearchScreenProps> = ({
  lang,
  onSelectCraftsman,
  onCall,
  onBack,
  presetLat,
  presetLng,
}) => {
  const t = translations[lang] || translations.ka;
  const [lat, setLat] = useState<number>(presetLat || 41.7151); // Tbilisi default
  const [lng, setLng] = useState<number>(presetLng || 44.8271);
  const [radiusKm, setRadiusKm] = useState<number>(15);
  const [craftsmen, setCraftsmen] = useState<CraftsmanPublic[]>([]);
  const [loading, setLoading] = useState(false);
  const [activePin, setActivePin] = useState<CraftsmanPublic | null>(null);

  const fetchNearby = async (targetLat: number, targetLng: number, radius: number) => {
    try {
      setLoading(true);
      const res = await api.searchNearby(targetLat, targetLng, radius, 1, 30);
      setCraftsmen(res.content || []);
    } catch (err) {
      console.error('Failed to load nearby craftsmen:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNearby(lat, lng, radiusKm);
  }, [lat, lng, radiusKm, lang]);

  const setCityPreset = (cityLat: number, cityLng: number) => {
    setLat(cityLat);
    setLng(cityLng);
  };

  return (
    <div className="flex-1 flex flex-col p-4 pb-20 space-y-4 animate-fade-in text-slate-100">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-amber-400" />
              <span>{t.mapSearch}</span>
            </h2>
            <p className="text-[11px] text-slate-400">
              {lang === 'ka'
                ? 'რუკაზე ძიება და ოსტატების ლოკაცია'
                : 'Nearby craftsmen on map'}
            </p>
          </div>
        </div>
      </div>

      {/* Georgia Map Canvas Simulation */}
      <div className="relative w-full h-56 bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-inner flex items-center justify-center">
        {/* Subtle grid background */}
        <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:16px_16px]" />

        {/* Outline of Georgia representation */}
        <svg
          className="absolute inset-0 w-full h-full opacity-30 pointer-events-none p-4"
          viewBox="0 0 100 60"
          preserveAspectRatio="none"
        >
          <path
            d="M 10 30 Q 30 15, 60 20 T 90 35 Q 80 50, 40 45 Z"
            fill="none"
            stroke="#f59e0b"
            strokeWidth="0.8"
            strokeDasharray="2,2"
          />
        </svg>

        {/* Center Target (User Location) */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center pointer-events-none">
          <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-400 animate-ping absolute" />
          <div className="w-4 h-4 rounded-full bg-amber-400 border-2 border-slate-950 flex items-center justify-center shadow-lg">
            <div className="w-1.5 h-1.5 rounded-full bg-slate-950" />
          </div>
          <span className="text-[9px] font-bold text-amber-300 bg-slate-950/80 px-1.5 py-0.2 rounded mt-1 border border-slate-800">
            GPS: {lat.toFixed(2)}, {lng.toFixed(2)}
          </span>
        </div>

        {/* Pins for Craftsmen */}
        {craftsmen.map((c, idx) => {
          // Compute pseudo offset on canvas relative to center
          const dLat = (c.latitude || 41.7) - lat;
          const dLng = (c.longitude || 44.8) - lng;
          const topPercent = Math.min(Math.max(50 - dLat * 180, 15), 85);
          const leftPercent = Math.min(Math.max(50 + dLng * 140, 15), 85);

          return (
            <button
              key={c.id}
              onClick={() => setActivePin(c)}
              style={{ top: `${topPercent}%`, left: `${leftPercent}%` }}
              className={`absolute -translate-x-1/2 -translate-y-1/2 z-30 transition-transform hover:scale-125 ${
                activePin?.id === c.id ? 'scale-125 z-40' : ''
              }`}
            >
              <div
                className={`p-1.5 rounded-full border shadow-md flex items-center justify-center ${
                  c.isTop15
                    ? 'bg-amber-500 border-amber-300 text-slate-950'
                    : 'bg-slate-800 border-slate-600 text-amber-400'
                }`}
              >
                <MapPin className="w-3.5 h-3.5 fill-current" />
              </div>
            </button>
          );
        })}

        {/* Map Legend */}
        <div className="absolute bottom-2 left-2 z-20 bg-slate-950/80 backdrop-blur-sm border border-slate-800 px-2 py-1 rounded-md text-[9px] text-slate-400 flex items-center gap-2">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-amber-500" /> TOP 15
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-slate-700" /> Regular
          </span>
        </div>
      </div>

      {/* Location Presets & Radius Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 space-y-3">
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-400 font-medium">
            {lang === 'ka' ? 'რადიუსი' : 'Radius'}: <strong className="text-amber-400">{radiusKm} km</strong>
          </span>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setCityPreset(41.7151, 44.8271)}
              className={`px-2 py-0.5 rounded text-[10px] border transition-colors ${
                Math.abs(lat - 41.7151) < 0.05
                  ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                  : 'bg-slate-800 border-slate-700 text-slate-400'
              }`}
            >
              თბილისი
            </button>
            <button
              onClick={() => setCityPreset(41.6168, 41.6367)}
              className={`px-2 py-0.5 rounded text-[10px] border transition-colors ${
                Math.abs(lat - 41.6168) < 0.05
                  ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                  : 'bg-slate-800 border-slate-700 text-slate-400'
              }`}
            >
              ბათუმი
            </button>
            <button
              onClick={() => setCityPreset(42.2679, 42.6946)}
              className={`px-2 py-0.5 rounded text-[10px] border transition-colors ${
                Math.abs(lat - 42.2679) < 0.05
                  ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                  : 'bg-slate-800 border-slate-700 text-slate-400'
              }`}
            >
              ქუთაისი
            </button>
          </div>
        </div>

        <input
          type="range"
          min="5"
          max="50"
          value={radiusKm}
          onChange={(e) => setRadiusKm(parseInt(e.target.value))}
          className="w-full accent-amber-500 cursor-pointer"
        />
      </div>

      {/* Selected Pin Popover Preview */}
      {activePin && (
        <div className="bg-gradient-to-r from-slate-900 to-amber-950/40 border border-amber-500/60 rounded-2xl p-3 flex items-center justify-between gap-3 animate-fade-in">
          <div
            className="flex-1 cursor-pointer"
            onClick={() => onSelectCraftsman(activePin)}
          >
            <div className="flex items-center gap-1.5">
              <h4 className="text-xs font-bold text-white">{activePin.name}</h4>
              {activePin.isTop15 && (
                <span className="text-[9px] bg-amber-500 text-slate-950 font-bold px-1 rounded">
                  TOP 15
                </span>
              )}
            </div>
            <p className="text-[11px] text-amber-300">
              {activePin.professionName} • {activePin.cityName}
            </p>
            {activePin.distanceKm !== undefined && (
              <p className="text-[10px] text-slate-400">
                {activePin.distanceKm} km away
              </p>
            )}
          </div>

          {activePin.phoneVisible && activePin.phone ? (
            <button
              onClick={() => onCall(activePin)}
              className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-3 py-1.5 rounded-xl shadow flex items-center gap-1"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>{t.call}</span>
            </button>
          ) : (
            <span className="text-[10px] text-slate-500 italic">{t.phoneHidden}</span>
          )}
        </div>
      )}

      {/* Craftsmen list sorted by distance */}
      <div className="space-y-2 pt-2">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1">
          {lang === 'ka' ? 'უახლოესი ხელოსნები' : 'Nearby Craftsmen'} ({craftsmen.length})
        </h3>

        {loading ? (
          <div className="py-8 text-center text-xs text-slate-500">
            {lang === 'ka' ? 'იტვირთება...' : 'Locating...'}
          </div>
        ) : craftsmen.length === 0 ? (
          <div className="py-6 text-center text-xs text-slate-500 bg-slate-900/50 rounded-xl border border-dashed border-slate-800">
            {lang === 'ka'
              ? 'არცერთი ხელოსანი არ მოიძებნა ამ რადიუსში. გაზარდეთ რადიუსი.'
              : 'No craftsmen found in this radius. Try increasing the radius slider.'}
          </div>
        ) : (
          craftsmen.map((c) => (
            <div
              key={c.id}
              onClick={() => onSelectCraftsman(c)}
              className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex items-center justify-between hover:border-slate-700 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-slate-800 overflow-hidden shrink-0 border border-slate-700">
                  {c.primaryPhotoUrl ? (
                    <img src={c.primaryPhotoUrl} alt={c.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-amber-400 font-bold">
                      {c.name.charAt(0)}
                    </div>
                  )}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">{c.name}</h4>
                  <p className="text-[11px] text-slate-400">{c.professionName}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-[11px] font-mono text-amber-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                  {c.distanceKm} km
                </span>
                {c.phoneVisible && c.phone && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onCall(c);
                    }}
                    className="p-2 bg-emerald-600 hover:bg-emerald-500 rounded-lg text-white"
                  >
                    <Phone className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
