import fs from 'fs';
import path from 'path';
import { Firestore } from '@google-cloud/firestore';
import {
  ListingPrice,
  Top15Price,
  Advertisement,
  ProviderConfig,
  RecipientAccount,
  ConfigLock,
} from './types.js';

export interface SuperAdminPersistedConfig {
  listingPrice: ListingPrice;
  top15Prices: Record<string, Top15Price>;
  advertisements: Advertisement[];
  providerConfig: ProviderConfig;
  recipientAccount: RecipientAccount;
  configLock: ConfigLock;
  bootstrap: {
    phone: string;
    password: string;
    enabled: boolean;
    invalidated: boolean;
    completedAt: string | null;
  };
  backendConfig: {
    baseUrl: string;
    issuedAt: string;
    signature: string;
  };
  version: number;
  lastPersistedAt: string;
}

export class StorageService {
  private firestore: Firestore | null = null;
  private isFirestoreReady: boolean = false;
  private storageDir: string;
  private snapshotFilePath: string;

  constructor() {
    this.storageDir = path.resolve(process.cwd(), 'data');
    this.snapshotFilePath = path.join(this.storageDir, 'superadmin_config.json');
    this.initFirestore();
  }

  private initFirestore() {
    try {
      let projectId =
        process.env.FIRESTORE_PROJECT_ID ||
        process.env.GOOGLE_CLOUD_PROJECT ||
        process.env.GCP_PROJECT;
      let databaseId: string | undefined = undefined;

      const firebaseConfigPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
      if (fs.existsSync(firebaseConfigPath)) {
        try {
          const cfg = JSON.parse(fs.readFileSync(firebaseConfigPath, 'utf8'));
          if (cfg.projectId) projectId = cfg.projectId;
          if (cfg.firestoreDatabaseId) databaseId = cfg.firestoreDatabaseId;
        } catch {
          // Ignore JSON parse errors
        }
      }

      const options: any = {};
      if (projectId) options.projectId = projectId;
      if (databaseId) options.databaseId = databaseId;

      this.firestore = new Firestore(options);
    } catch (err: any) {
      console.warn('[STORAGE] Firestore client init skipped (using snapshot fallback):', err?.message || err);
      this.firestore = null;
    }
  }

  /**
   * Hydrate configuration on startup.
   * Checks Cloud Firestore first; falls back to local snapshot file.
   */
  async loadSuperAdminConfig(): Promise<SuperAdminPersistedConfig | null> {
    if (this.firestore) {
      try {
        const metaDoc = await this.firestore.collection('superadmin_config').doc('meta').get();
        if (metaDoc.exists) {
          const [
            listingPriceDoc,
            top15PricesDoc,
            adsDoc,
            providerConfigDoc,
            recipientAccountDoc,
            configLockDoc,
            bootstrapDoc,
            backendConfigDoc,
          ] = await Promise.all([
            this.firestore.collection('superadmin_config').doc('listing_price').get(),
            this.firestore.collection('superadmin_config').doc('top15_prices').get(),
            this.firestore.collection('superadmin_config').doc('advertisements').get(),
            this.firestore.collection('superadmin_config').doc('provider_config').get(),
            this.firestore.collection('superadmin_config').doc('recipient_account').get(),
            this.firestore.collection('superadmin_config').doc('config_lock').get(),
            this.firestore.collection('superadmin_config').doc('bootstrap').get(),
            this.firestore.collection('superadmin_config').doc('backend_config').get(),
          ]);

          const metaData = metaDoc.data() || {};
          const loadedConfig: SuperAdminPersistedConfig = {
            listingPrice: (listingPriceDoc.data() as ListingPrice) || {
              amountMinor: 1000,
              currency: 'GEL',
              updatedAt: new Date().toISOString(),
              updatedBy: 'system',
            },
            top15Prices: (top15PricesDoc.data()?.prices as Record<string, Top15Price>) || {},
            advertisements: (adsDoc.data()?.ads as Advertisement[]) || [],
            providerConfig: (providerConfigDoc.data() as ProviderConfig) || ({} as any),
            recipientAccount: (recipientAccountDoc.data() as RecipientAccount) || ({} as any),
            configLock: (configLockDoc.data() as ConfigLock) || ({} as any),
            bootstrap: (bootstrapDoc.data() as any) || ({} as any),
            backendConfig: (backendConfigDoc.data() as any) || ({} as any),
            version: metaData.version || 1,
            lastPersistedAt: metaData.lastPersistedAt || new Date().toISOString(),
          };

          this.isFirestoreReady = true;
          console.log('[STORAGE] SuperAdmin configuration loaded from Cloud Firestore.');

          // Sync local snapshot for redundancy
          this.saveLocalSnapshot(loadedConfig);
          return loadedConfig;
        }
      } catch (err: any) {
        console.warn('[STORAGE] Firestore read attempt failed, checking local snapshot:', err.message);
        this.isFirestoreReady = false;
      }
    }

    // Local snapshot is development-only. Cloud Run production must fail closed.
    if (process.env.NODE_ENV === 'production') return null;
    return this.loadLocalSnapshot();
  }

  /**
   * Persists superadmin configuration across restarts.
   * Atomically writes to local snapshot file AND saves batch to Cloud Firestore.
   */
  async saveSuperAdminConfig(
    config: SuperAdminPersistedConfig
  ): Promise<{ success: boolean; firestore: boolean; snapshot: boolean; error?: string }> {
    let snapshotSaved = false;
    let firestoreSaved = false;
    let errorDetail: string | undefined;

    // 1. Atomic local snapshot
    if (process.env.NODE_ENV !== 'production') {
      try {
        this.saveLocalSnapshot(config);
        snapshotSaved = true;
      } catch (err: any) {
        console.error('[STORAGE] Failed to write local snapshot file:', err);
        errorDetail = err.message;
      }
    }

    // 2. Cloud Firestore batch write
    if (this.firestore) {
      try {
        const batch = this.firestore.batch();
        const col = this.firestore.collection('superadmin_config');

        batch.set(col.doc('listing_price'), config.listingPrice);
        batch.set(col.doc('top15_prices'), { prices: config.top15Prices });
        batch.set(col.doc('advertisements'), { ads: config.advertisements });
        batch.set(col.doc('provider_config'), config.providerConfig);
        batch.set(col.doc('recipient_account'), config.recipientAccount);
        batch.set(col.doc('config_lock'), config.configLock);
        batch.set(col.doc('bootstrap'), config.bootstrap);
        batch.set(col.doc('backend_config'), config.backendConfig);
        batch.set(col.doc('meta'), {
          version: config.version,
          lastPersistedAt: config.lastPersistedAt,
        });

        await batch.commit();
        firestoreSaved = true;
        this.isFirestoreReady = true;
      } catch (err: any) {
        console.warn('[STORAGE] Firestore write failed:', err.message);
        this.isFirestoreReady = false;
        if (!errorDetail) errorDetail = err.message;
      }
    }

    return {
      success: snapshotSaved || firestoreSaved,
      firestore: firestoreSaved,
      snapshot: snapshotSaved,
      error: errorDetail,
    };
  }

  private loadLocalSnapshot(): SuperAdminPersistedConfig | null {
    try {
      if (fs.existsSync(this.snapshotFilePath)) {
        const data = fs.readFileSync(this.snapshotFilePath, 'utf-8');
        const parsed = JSON.parse(data) as SuperAdminPersistedConfig;
        console.log('[STORAGE] SuperAdmin configuration loaded from local snapshot file.');
        return parsed;
      }
    } catch (err: any) {
      console.error('[STORAGE] Error reading local snapshot file:', err);
    }
    return null;
  }

  private saveLocalSnapshot(config: SuperAdminPersistedConfig): void {
    if (!fs.existsSync(this.storageDir)) {
      fs.mkdirSync(this.storageDir, { recursive: true });
    }
    const tempFile = `${this.snapshotFilePath}.${Date.now()}.tmp`;
    fs.writeFileSync(tempFile, JSON.stringify(config, null, 2), 'utf-8');
    fs.renameSync(tempFile, this.snapshotFilePath);
  }

  async loadRuntimeCollection<T = any>(collectionName: string): Promise<Record<string, T>> {
    const result: Record<string, T> = {};
    if (this.firestore) {
      try {
        const snap = await this.firestore.collection('masterboy_runtime').doc(collectionName).collection('items').get();
        snap.forEach((doc) => { result[doc.id] = (doc.data().value as T); });
        this.isFirestoreReady = true;
        return result;
      } catch (err: any) {
        console.warn(`[STORAGE] Runtime collection ${collectionName} load failed:`, err?.message || err);
      }
    }
    // Never fall back to a local runtime snapshot in production. Cloud Run's
    // filesystem is ephemeral and using it as a fallback can silently create
    // divergent state between instances.
    if (process.env.NODE_ENV === 'production') return result;
    try {
      const file = path.join(this.storageDir, `runtime_${collectionName}.json`);
      if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8')) as Record<string, T>;
    } catch (err: any) {
      console.warn(`[STORAGE] Runtime snapshot ${collectionName} load failed:`, err?.message || err);
    }
    return result;
  }

  async saveRuntimeCollection<T = any>(collectionName: string, values: Map<string, T>): Promise<void> {
    const entries = Array.from(values.entries());
    if (this.firestore) {
      try {
        const col = this.firestore.collection('masterboy_runtime').doc(collectionName).collection('items');
        const existing = await col.get();
        const ops: Array<{ type: 'delete' | 'set'; ref: any; value?: any }> = [];
        existing.forEach((doc) => { if (!values.has(doc.id)) ops.push({ type: 'delete', ref: doc.ref }); });
        for (const [id, value] of entries) ops.push({ type: 'set', ref: col.doc(id), value: { value, updatedAt: new Date().toISOString() } });
        for (let i = 0; i < ops.length; i += 450) {
          const batch = this.firestore.batch();
          for (const op of ops.slice(i, i + 450)) {
            if (op.type === 'delete') batch.delete(op.ref);
            else batch.set(op.ref, op.value);
          }
          await batch.commit();
        }
        this.isFirestoreReady = true;
        return;
      } catch (err: any) {
        console.warn(`[STORAGE] Runtime collection ${collectionName} save failed:`, err?.message || err);
      }
    }
    if (process.env.NODE_ENV === 'production') return;
    try {
      if (!fs.existsSync(this.storageDir)) fs.mkdirSync(this.storageDir, { recursive: true });
      const file = path.join(this.storageDir, `runtime_${collectionName}.json`);
      const temp = `${file}.${Date.now()}.tmp`;
      fs.writeFileSync(temp, JSON.stringify(Object.fromEntries(values), null, 2), 'utf8');
      fs.renameSync(temp, file);
    } catch (err: any) {
      console.warn(`[STORAGE] Runtime snapshot ${collectionName} save failed:`, err?.message || err);
    }
  }

  async loadRuntimeArray<T = any>(name: string): Promise<T[]> {
    const collection = await this.loadRuntimeCollection<T>(`__array_${name}`);
    return Object.keys(collection).sort().map((k) => collection[k]);
  }

  async saveRuntimeArray<T = any>(name: string, values: T[]): Promise<void> {
    const map = new Map<string, T>();
    values.forEach((value, index) => {
      const id = (value && typeof value === 'object' && 'id' in (value as any)) ? String((value as any).id) : String(index).padStart(12, '0');
      map.set(id, value);
    });
    await this.saveRuntimeCollection(`__array_${name}`, map);
  }

  getStatus() {
    return {
      firestoreConfigured: !!this.firestore,
      firestoreConnected: this.isFirestoreReady,
      snapshotFileExists: fs.existsSync(this.snapshotFilePath),
      snapshotPath: this.snapshotFilePath,
    };
  }
}

export const storage = new StorageService();
